<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "gjk"; // this must match your phpMyAdmin DB name

$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Database Connection Failed: " . mysqli_connect_error());
}
?>
