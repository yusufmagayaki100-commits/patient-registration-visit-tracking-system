-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2026 at 11:00 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gjk`
--

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `sno` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `time` time NOT NULL,
  `date` date NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`sno`, `user`, `time`, `date`, `type`) VALUES
(14, 'emcube', '10:51:55', '2026-01-30', 'normal'),
(13, 'emcube', '10:50:11', '2026-01-28', 'normal');

-- --------------------------------------------------------

--
-- Table structure for table `obfirst`
--

CREATE TABLE `obfirst` (
  `rkey` varchar(100) NOT NULL,
  `lmp` date NOT NULL,
  `ga_lmp` varchar(100) NOT NULL,
  `eod_lmp` date NOT NULL,
  `ga_usg` varchar(100) NOT NULL,
  `eod_usg` date NOT NULL,
  `crl` varchar(30) NOT NULL,
  `ges_week` int(5) NOT NULL,
  `ges_day` int(5) NOT NULL,
  `ro` varchar(30) NOT NULL,
  `rom` varchar(30) NOT NULL,
  `lo` varchar(30) NOT NULL,
  `lom` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `obfirst`
--

INSERT INTO `obfirst` (`rkey`, `lmp`, `ga_lmp`, `eod_lmp`, `ga_usg`, `eod_usg`, `crl`, `ges_week`, `ges_day`, `ro`, `rom`, `lo`, `lom`) VALUES
('CXQxzNuY1C', '2026-01-08', '3weeks 1days ', '2026-09-15', '2 weeks 0 days', '2026-01-08', '20', 3, 20, 'ni', ' 0 X 0 X 0 ', 'mil', ' 0 X 0 X 0 ');

-- --------------------------------------------------------

--
-- Table structure for table `obtwo`
--

CREATE TABLE `obtwo` (
  `bpd` varchar(30) NOT NULL,
  `hc` varchar(30) NOT NULL,
  `ac` varchar(30) NOT NULL,
  `fl` varchar(30) NOT NULL,
  `placenta` varchar(30) NOT NULL,
  `liquor` varchar(30) NOT NULL,
  `afi` varchar(30) NOT NULL,
  `fhr` varchar(30) NOT NULL,
  `fwt` varchar(30) NOT NULL,
  `mi` varchar(30) NOT NULL,
  `geswk` varchar(30) NOT NULL,
  `gesdays` varchar(30) NOT NULL,
  `cl` varchar(30) NOT NULL,
  `rkey` varchar(30) NOT NULL,
  `bpdwd` varchar(30) NOT NULL,
  `hcwd` varchar(30) NOT NULL,
  `acwd` varchar(30) NOT NULL,
  `flwd` varchar(30) NOT NULL,
  `sdate` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patient_record_header`
--

CREATE TABLE `patient_record_header` (
  `pid` int(11) NOT NULL,
  `age` int(5) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `referredby` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `study` varchar(100) NOT NULL,
  `indication` varchar(100) NOT NULL,
  `rkey` varchar(50) NOT NULL,
  `attendedby` varchar(50) NOT NULL,
  `report_type` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_record_header`
--

INSERT INTO `patient_record_header` (`pid`, `age`, `gender`, `referredby`, `name`, `date`, `study`, `indication`, `rkey`, `attendedby`, `report_type`, `status`) VALUES
(45, 20, 'male', 'dr emcube', 'magayaki', '2026-01-30', 'Obstetrics', '2', 'CXQxzNuY1C', 'emcube', 'ogone', 'notPrinted');

-- --------------------------------------------------------

--
-- Table structure for table `pelvis`
--

CREATE TABLE `pelvis` (
  `rkey` varchar(30) NOT NULL,
  `tvaginal` varchar(30) NOT NULL,
  `tabdominal` varchar(30) NOT NULL,
  `uterus_appeared` varchar(30) NOT NULL,
  `uterus_measure` varchar(200) NOT NULL,
  `cavity` varchar(20) NOT NULL,
  `ro_measure` varchar(200) NOT NULL,
  `ro_appear` varchar(50) NOT NULL,
  `ro_comment` varchar(100) NOT NULL,
  `lo_mesure` varchar(200) NOT NULL,
  `lo_appear` varchar(50) NOT NULL,
  `lo_comment` varchar(100) NOT NULL,
  `date1` date NOT NULL,
  `day1` varchar(20) NOT NULL,
  `ro1` varchar(50) NOT NULL,
  `lo1` varchar(50) NOT NULL,
  `et1` varchar(20) NOT NULL,
  `date2` date DEFAULT NULL,
  `day2` varchar(20) DEFAULT NULL,
  `ro2` varchar(50) DEFAULT NULL,
  `lo2` varchar(50) DEFAULT NULL,
  `et2` varchar(20) DEFAULT NULL,
  `date3` date DEFAULT NULL,
  `day3` varchar(20) DEFAULT NULL,
  `ro3` varchar(50) DEFAULT NULL,
  `lo3` varchar(50) DEFAULT NULL,
  `et3` varchar(20) DEFAULT NULL,
  `date4` date DEFAULT NULL,
  `day4` varchar(20) DEFAULT NULL,
  `ro4` varchar(50) DEFAULT NULL,
  `lo4` varchar(50) DEFAULT NULL,
  `et4` varchar(20) DEFAULT NULL,
  `impression` varchar(250) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pelvistwo`
--

CREATE TABLE `pelvistwo` (
  `rkey` varchar(30) NOT NULL,
  `tvaginal` varchar(20) NOT NULL,
  `tabdominal` varchar(20) NOT NULL,
  `uterus_appeared` varchar(30) NOT NULL,
  `u_measured` varchar(100) NOT NULL,
  `cavity` varchar(50) NOT NULL,
  `endomaterial_thickness` varchar(50) NOT NULL,
  `ro_measure` varchar(100) NOT NULL,
  `ro` varchar(50) NOT NULL,
  `ro_comment` varchar(200) NOT NULL,
  `lo_measure` varchar(100) NOT NULL,
  `lo` varchar(50) NOT NULL,
  `lo_comment` varchar(200) NOT NULL,
  `impression` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelvistwo`
--

INSERT INTO `pelvistwo` (`rkey`, `tvaginal`, `tabdominal`, `uterus_appeared`, `u_measured`, `cavity`, `endomaterial_thickness`, `ro_measure`, `ro`, `ro_comment`, `lo_measure`, `lo`, `lo_comment`, `impression`) VALUES
('rCuc8CN90h', 'yes', 'no', 'antiverted', '1 X 0 X 3', 'abnormal', '6', '2 X 2 X 2', 'abnormal', 'Demo', '2 X 0 X 0', 'abnormal', 'Demo', 'This is a demo impression text for testing purpose!');

-- --------------------------------------------------------

--
-- Table structure for table `user_account`
--

CREATE TABLE `user_account` (
  `ID` int(8) NOT NULL,
  `username` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `degree` varchar(60) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_account`
--

INSERT INTO `user_account` (`ID`, `username`, `type`, `password`, `fullname`, `address`, `email`, `phone`, `dob`, `degree`) VALUES
(1, 'admin', 'admin', 'Password@123', 'YUSUF MAGAYAKI', 'Kano , Nigeria', 'magayaki001@gmail.com', '8136609766', '2003-06-17', 'MD (O&G)'),
(6, 'emcube', 'normal', 'emcube', 'emcube', 'GUSAU', 'emcube001@gmail.com', '9120478487', '2006-01-28', 'BSC MEDICINE');

-- --------------------------------------------------------

--
-- Table structure for table `visits`
--

CREATE TABLE `visits` (
  `id` int(11) NOT NULL,
  `patient_id` varchar(50) NOT NULL,
  `visit_date` date NOT NULL,
  `visit_reason` varchar(255) NOT NULL,
  `notes` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visits`
--

INSERT INTO `visits` (`id`, `patient_id`, `visit_date`, `visit_reason`, `notes`) VALUES
(4, '1', '2026-01-30', 'sick', 'his brother want to visit him and give some food');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `obfirst`
--
ALTER TABLE `obfirst`
  ADD UNIQUE KEY `rkey` (`rkey`);

--
-- Indexes for table `obtwo`
--
ALTER TABLE `obtwo`
  ADD UNIQUE KEY `rkey` (`rkey`);

--
-- Indexes for table `patient_record_header`
--
ALTER TABLE `patient_record_header`
  ADD PRIMARY KEY (`pid`),
  ADD UNIQUE KEY `rkey` (`rkey`);

--
-- Indexes for table `pelvis`
--
ALTER TABLE `pelvis`
  ADD UNIQUE KEY `rkey` (`rkey`);

--
-- Indexes for table `user_account`
--
ALTER TABLE `user_account`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `visits`
--
ALTER TABLE `visits`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `patient_record_header`
--
ALTER TABLE `patient_record_header`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `user_account`
--
ALTER TABLE `user_account`
  MODIFY `ID` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `visits`
--
ALTER TABLE `visits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
