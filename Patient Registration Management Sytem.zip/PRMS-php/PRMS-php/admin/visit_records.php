<?php
include("../db/db_connect.php");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Patient Visit Records</title>
    <link rel="stylesheet" href="../theme/style.css">
</head>
<body>

<h2>Patient Visit Records</h2>

<table border="1" cellpadding="8">
<tr>
    <th>Patient ID</th>
    <th>Visit Date</th>
    <th>Reason</th>
    <th>Notes</th>
</tr>

<?php
$sql = "SELECT patient_id, visit_date, visit_reason, notes FROM visits ORDER BY visit_date DESC";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("SQL ERROR: " . mysqli_error($conn));
}

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>
        <td>{$row['patient_id']}</td>
        <td>{$row['visit_date']}</td>
        <td>{$row['visit_reason']}</td>
        <td>{$row['notes']}</td>
    </tr>";
}
?>

</table>

</body>
</html>
