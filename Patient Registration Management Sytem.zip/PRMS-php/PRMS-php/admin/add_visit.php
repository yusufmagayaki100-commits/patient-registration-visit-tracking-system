<?php
if (!isset($_SESSION)) {
    session_start();
}
include("../db/db_connect.php");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Patient Visit</title>
    <link rel="stylesheet" href="../theme/style.css">
</head>
<body>

<h2>Add Patient Visit</h2>

<form method="post">
    <label>Patient ID</label><br>
    <input type="text" name="patient_id" required><br><br>

    <label>Visit Reason</label><br>
    <input type="text" name="visit_reason" required><br><br>

    <label>Notes</label><br>
    <textarea name="notes"></textarea><br><br>

    <button type="submit" name="save">Save Visit</button>
</form>

<?php
if(isset($_POST['save'])){

    $patient_id   = $_POST['patient_id'];
    $visit_reason = $_POST['visit_reason'];
    $notes        = $_POST['notes'];

    $query = "INSERT INTO visits 
              (patient_id, visit_date, visit_reason, notes)
              VALUES ('$patient_id', CURDATE(), '$visit_reason', '$notes')";

    if(mysqli_query($conn, $query)){
        echo "<p style='color:green;'>Visit Record Saved Successfully</p>";
    } else {
        echo "<p style='color:red;'>Error: " . mysqli_error($conn) . "</p>";
    }
}
?>

</body>
</html>
